using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Targeting : SingletonMonoBehaviour<Targeting>
{
    [SerializeField] Transform m_firePos;
    public List<GameObject> m_unitList;
    float m_currentDist;
    float m_maxDist = 10f;
    Vector3 m_dir;
    
    public GameObject GetMonsterNearest(Vector3 target) //���� ����� ���͸� ����Ʈ���� ã��
    {
        if (m_unitList.Count == 0) return null;

        m_maxDist = (target - m_unitList[0].transform.position).sqrMagnitude;
        int index = 0;
        for (int i = 1; i < m_unitList.Count; i++)
        {
            var dist = (target - m_unitList[i].transform.position).sqrMagnitude;
            if (m_maxDist > dist)
            {
                m_maxDist = dist;
                index = i;
            }
        }
        return m_unitList[index];
    }
    public Vector3 GetTargetDir()
    {
        var target = GetMonsterNearest(transform.position);
        if (target == null || target.gameObject.activeSelf == false)
        {
            return Vector3.zero;
        }

        var dir = target.transform.position - transform.position;
        dir.y = 0f;
        return dir.normalized;
    }
    void OnDrawGizmos()
    {
        for (int i = 0; i < m_unitList.Count; i++)
        {
            RaycastHit hit;
            bool isHit = Physics.Raycast(transform.position, m_unitList[i].transform.position - transform.position, out hit, 10f, 1 << LayerMask.NameToLayer("Monster"));
            if (isHit && hit.collider.CompareTag("Monster"))
            {
                Gizmos.color = Color.red;
            }
            else
            {
                Gizmos.color = Color.green;
            }
            Gizmos.DrawRay(transform.position, m_unitList[i].transform.position - transform.position);
        }
    }
}
