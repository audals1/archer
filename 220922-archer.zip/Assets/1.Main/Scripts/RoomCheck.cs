using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomCheck : SingletonMonoBehaviour<RoomCheck>
{
    public List<GameObject> m_monsterinroom;
    void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Player"))
        {
          Debug.Log("�÷��̾�����");
        }
        if (other.CompareTag("Monster"))
        {
            Targeting.Instance.m_unitList = m_monsterinroom;
            m_monsterinroom.Add(other.gameObject);
            Debug.Log(other.name);
        }
    }
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Monster"))
        {
            m_monsterinroom.Remove(other.gameObject);
        }
    }
}
