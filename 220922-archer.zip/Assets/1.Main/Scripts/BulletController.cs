using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour
{
    [SerializeField]
    PlayerController m_player;
    [SerializeField]
    float m_speed = 15f;
    Vector3 m_targetDir;
    
    public void Initialize(PlayerController player)
    {
        m_player = player;
        
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("BackGround") || (other.CompareTag("Monster")))
        {
            BulletManager.Instance.ReturnBullet(this);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
    
    }
    // Update is called once per frame
    void Update()
    {
        m_targetDir = Targeting.Instance.GetTargetDir();
        transform.position += m_targetDir * m_speed * Time.deltaTime;
    }
}
